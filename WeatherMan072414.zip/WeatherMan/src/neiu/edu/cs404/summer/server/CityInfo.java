package neiu.edu.cs404.summer.server;

public class CityInfo {
	String name;
	String code;
	String URL;
	String fileName;
	String metarURL;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getURL() {
		return URL;
	}

	public void setURL(String url) {
		this.URL = url;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getMetarURL() {
		return metarURL;
	}

	public void setMetarURL(String metarURL) {
		this.metarURL = metarURL;
	}
	
	

}
