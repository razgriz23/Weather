package neiu.edu.cs404.summer.shared;

public interface SkyCondition {
	public static final String RAIN = "RAIN"; 
	public static final String CLOUDY = "CLOUDY";
	public static final String FOG = "FOG";
	public static final String PARTLY_CLOUDY = "PARTLY_CLOUDY";
	public static final String THUNDERSTORM = "THUNDERSTORM";
	public static final String SUNNY = "SUNNY";
}	
